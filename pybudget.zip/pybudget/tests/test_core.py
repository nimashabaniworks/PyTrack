"""Tests for pybudget.core using a temporary database."""

import pytest
from pybudget import core


@pytest.fixture
def db(tmp_path):
    return str(tmp_path / "test.db")


def test_add_and_list(db):
    core.add_transaction("income", "salary", 1000, date="2026-01-01", db_path=db)
    core.add_transaction("expense", "food", 50, date="2026-01-02", db_path=db)

    transactions = core.list_transactions(db_path=db)
    assert len(transactions) == 2


def test_invalid_type_raises(db):
    with pytest.raises(ValueError):
        core.add_transaction("weird", "food", 10, db_path=db)


def test_negative_amount_raises(db):
    with pytest.raises(ValueError):
        core.add_transaction("expense", "food", -10, db_path=db)


def test_delete_transaction(db):
    tid = core.add_transaction("expense", "food", 20, db_path=db)
    assert core.delete_transaction(tid, db_path=db) is True
    assert core.delete_transaction(9999, db_path=db) is False


def test_summary(db):
    core.add_transaction("income", "salary", 2000, date="2026-01-01", db_path=db)
    core.add_transaction("expense", "rent", 800, date="2026-01-05", db_path=db)
    core.add_transaction("expense", "food", 200, date="2026-01-10", db_path=db)

    summary = core.get_summary(month="2026-01", db_path=db)
    assert summary["total_income"] == 2000
    assert summary["total_expense"] == 1000
    assert summary["balance"] == 1000
    assert summary["by_category"]["rent"] == -800


def test_filter_by_month(db):
    core.add_transaction("income", "salary", 100, date="2026-01-01", db_path=db)
    core.add_transaction("income", "salary", 200, date="2026-02-01", db_path=db)

    jan = core.list_transactions(month="2026-01", db_path=db)
    assert len(jan) == 1
    assert jan[0].amount == 100
