# PyBudget 💰

A simple, offline **personal finance & budget tracker** for the command line, built in pure Python (standard library only, no external services or API keys required).

Track your income and expenses, categorize them, see monthly summaries, and export your data to CSV — all stored locally in a lightweight SQLite database.

## Features

- ➕ Add income and expense transactions with category, amount, date, and notes
- 📋 List and filter transactions by type, category, or month
- 📊 Monthly summary with totals and per-category breakdown
- 🗑️ Delete transactions by ID
- 📁 Export transactions to CSV
- 🎨 Colorized terminal output
- 🧪 Fully tested with `pytest`
- 🗄️ Local SQLite storage — your data never leaves your machine

## Installation

```bash
git clone https://github.com/<your-username>/pybudget.git
cd pybudget
pip install -e .
```

## Usage

```bash
# Add transactions
pybudget add income salary 3000 --note "July paycheck"
pybudget add expense rent 900
pybudget add expense food 45.50 --date 2026-07-15

# List transactions
pybudget list
pybudget list --type expense --month 2026-07

# View a summary
pybudget summary --month 2026-07

# Export to CSV
pybudget export report.csv --month 2026-07

# Delete a transaction
pybudget delete 3
```

## Running tests

```bash
pip install -r requirements.txt
pytest
```

## Project structure

```
pybudget/
├── pybudget/
│   ├── __init__.py
│   ├── cli.py         # Command-line interface (argparse)
│   ├── core.py         # Business logic (add/list/delete/summary/export)
│   └── database.py     # SQLite connection & schema
├── tests/
│   └── test_core.py
├── pyproject.toml
├── requirements.txt
├── LICENSE
└── README.md
```

## Why this project?

This project is intentionally kept dependency-free (aside from `pytest` for testing) so it's easy to read, run, and extend. It's a good example of clean CLI architecture in Python: separating the **data layer** (`database.py`), **business logic** (`core.py`), and **presentation layer** (`cli.py`).

## Ideas for extending it

- Add a `--budget` command to set monthly limits per category and get warnings
- Build a simple web dashboard with Flask + Chart.js
- Add recurring transactions (e.g. monthly rent auto-added)
- Support multiple currencies

## License

MIT — see [LICENSE](LICENSE).
