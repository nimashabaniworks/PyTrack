"""Core operations: add, list, delete transactions and generate reports."""

from datetime import datetime
from dataclasses import dataclass

from pybudget.database import get_connection


@dataclass
class Transaction:
    id: int
    date: str
    type: str
    category: str
    amount: float
    note: str | None


def add_transaction(
    kind: str,
    category: str,
    amount: float,
    note: str = "",
    date: str | None = None,
    db_path: str | None = None,
) -> int:
    """Add a new income/expense transaction. Returns the new row id."""
    if kind not in ("income", "expense"):
        raise ValueError("type must be 'income' or 'expense'")
    if amount <= 0:
        raise ValueError("amount must be positive")

    date = date or datetime.now().strftime("%Y-%m-%d")

    with get_connection(db_path) as conn:
        cur = conn.execute(
            "INSERT INTO transactions (date, type, category, amount, note) "
            "VALUES (?, ?, ?, ?, ?)",
            (date, kind, category, amount, note),
        )
        conn.commit()
        return cur.lastrowid


def list_transactions(
    kind: str | None = None,
    category: str | None = None,
    month: str | None = None,
    db_path: str | None = None,
) -> list[Transaction]:
    """List transactions, optionally filtered by type, category, or month (YYYY-MM)."""
    query = "SELECT * FROM transactions WHERE 1=1"
    params: list = []

    if kind:
        query += " AND type = ?"
        params.append(kind)
    if category:
        query += " AND category = ?"
        params.append(category)
    if month:
        query += " AND date LIKE ?"
        params.append(f"{month}%")

    query += " ORDER BY date DESC, id DESC"

    with get_connection(db_path) as conn:
        rows = conn.execute(query, params).fetchall()
        return [Transaction(**dict(row)) for row in rows]


def delete_transaction(transaction_id: int, db_path: str | None = None) -> bool:
    """Delete a transaction by id. Returns True if a row was deleted."""
    with get_connection(db_path) as conn:
        cur = conn.execute("DELETE FROM transactions WHERE id = ?", (transaction_id,))
        conn.commit()
        return cur.rowcount > 0


def get_summary(month: str | None = None, db_path: str | None = None) -> dict:
    """Return totals for income, expense, balance, and per-category breakdown."""
    transactions = list_transactions(month=month, db_path=db_path)

    total_income = sum(t.amount for t in transactions if t.type == "income")
    total_expense = sum(t.amount for t in transactions if t.type == "expense")

    by_category: dict[str, float] = {}
    for t in transactions:
        sign = 1 if t.type == "income" else -1
        by_category[t.category] = by_category.get(t.category, 0) + sign * t.amount

    return {
        "total_income": total_income,
        "total_expense": total_expense,
        "balance": total_income - total_expense,
        "by_category": by_category,
        "count": len(transactions),
    }


def export_csv(filepath: str, month: str | None = None, db_path: str | None = None) -> int:
    """Export transactions to a CSV file. Returns the number of rows written."""
    import csv

    transactions = list_transactions(month=month, db_path=db_path)
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["id", "date", "type", "category", "amount", "note"])
        for t in transactions:
            writer.writerow([t.id, t.date, t.type, t.category, t.amount, t.note or ""])
    return len(transactions)
