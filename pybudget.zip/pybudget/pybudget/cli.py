"""Command-line interface for PyBudget."""

import argparse
import sys

from pybudget import core

RESET = "\033[0m"
GREEN = "\033[92m"
RED = "\033[91m"
BOLD = "\033[1m"


def cmd_add(args):
    tid = core.add_transaction(
        kind=args.type,
        category=args.category,
        amount=args.amount,
        note=args.note or "",
        date=args.date,
    )
    color = GREEN if args.type == "income" else RED
    print(f"{color}✔ Added {args.type} #{tid}: {args.amount} in '{args.category}'{RESET}")


def cmd_list(args):
    transactions = core.list_transactions(kind=args.type, category=args.category, month=args.month)
    if not transactions:
        print("No transactions found.")
        return

    print(f"{'ID':<5}{'Date':<12}{'Type':<10}{'Category':<15}{'Amount':>10}  Note")
    print("-" * 70)
    for t in transactions:
        color = GREEN if t.type == "income" else RED
        print(f"{t.id:<5}{t.date:<12}{color}{t.type:<10}{RESET}{t.category:<15}{t.amount:>10.2f}  {t.note or ''}")


def cmd_delete(args):
    ok = core.delete_transaction(args.id)
    if ok:
        print(f"✔ Deleted transaction #{args.id}")
    else:
        print(f"✘ No transaction found with id #{args.id}")
        sys.exit(1)


def cmd_summary(args):
    summary = core.get_summary(month=args.month)
    period = args.month or "all time"
    print(f"{BOLD}Summary ({period}){RESET}")
    print(f"  Transactions : {summary['count']}")
    print(f"  {GREEN}Income  : {summary['total_income']:.2f}{RESET}")
    print(f"  {RED}Expense : {summary['total_expense']:.2f}{RESET}")
    balance_color = GREEN if summary["balance"] >= 0 else RED
    print(f"  {BOLD}Balance : {balance_color}{summary['balance']:.2f}{RESET}")

    if summary["by_category"]:
        print(f"\n{BOLD}By category:{RESET}")
        for cat, net in sorted(summary["by_category"].items(), key=lambda x: -abs(x[1])):
            color = GREEN if net >= 0 else RED
            print(f"  {cat:<20}{color}{net:>10.2f}{RESET}")


def cmd_export(args):
    count = core.export_csv(args.output, month=args.month)
    print(f"✔ Exported {count} transactions to {args.output}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pybudget",
        description="A simple, offline personal finance & budget tracker.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    p_add = subparsers.add_parser("add", help="Add a new transaction")
    p_add.add_argument("type", choices=["income", "expense"])
    p_add.add_argument("category", help="e.g. food, rent, salary")
    p_add.add_argument("amount", type=float)
    p_add.add_argument("--note", help="Optional note")
    p_add.add_argument("--date", help="YYYY-MM-DD (defaults to today)")
    p_add.set_defaults(func=cmd_add)

    p_list = subparsers.add_parser("list", help="List transactions")
    p_list.add_argument("--type", choices=["income", "expense"])
    p_list.add_argument("--category")
    p_list.add_argument("--month", help="Filter by YYYY-MM")
    p_list.set_defaults(func=cmd_list)

    p_delete = subparsers.add_parser("delete", help="Delete a transaction by id")
    p_delete.add_argument("id", type=int)
    p_delete.set_defaults(func=cmd_delete)

    p_summary = subparsers.add_parser("summary", help="Show income/expense summary")
    p_summary.add_argument("--month", help="Filter by YYYY-MM")
    p_summary.set_defaults(func=cmd_summary)

    p_export = subparsers.add_parser("export", help="Export transactions to CSV")
    p_export.add_argument("output", help="Output CSV file path")
    p_export.add_argument("--month", help="Filter by YYYY-MM")
    p_export.set_defaults(func=cmd_export)

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
