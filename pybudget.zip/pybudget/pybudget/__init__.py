"""PyBudget - A simple, offline personal finance & budget tracker."""

__version__ = "1.0.0"
